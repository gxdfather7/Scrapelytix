This is a project on soccer analytics 
Twitter/X : @gxdfather_ || @rolaazz